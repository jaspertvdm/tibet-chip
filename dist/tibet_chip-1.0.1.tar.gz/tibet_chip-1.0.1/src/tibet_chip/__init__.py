"""TIBET Safety Chip - Hardware-like AI Security at TPM Cost"""
__version__ = "1.0.0"
