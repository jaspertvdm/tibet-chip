"""Entry point for python -m tibet_chip"""
from .server import run

if __name__ == "__main__":
    run()
